import Image from "next/image";

export default function Home() {
  return (
    <main> 
      <h1>Task Management Application</h1>    
    </main>
  );
}
