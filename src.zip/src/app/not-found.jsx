import React from 'react'

export default function NotFound() {
  return (
    <div>
       <h1> Oh oh! The page doesn&apos;t exist. Make sure you have no typos in your URL</h1>
    </div>
  )
}
